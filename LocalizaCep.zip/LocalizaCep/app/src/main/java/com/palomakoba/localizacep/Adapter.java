package com.palomakoba.localizacep;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {
    private List<ContentValues> endereco_lista = new ArrayList<>();


    public Adapter(List<ContentValues> endereco_lista) {
        this.endereco_lista = endereco_lista;

    }

    @NonNull
    @Override
    public Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_endereco, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.MyViewHolder holder, int position) {
        ContentValues cv = new ContentValues();
        cv = endereco_lista.get(position);

        String cep = cv.getAsString("CEP");
        String logradouro = cv.getAsString("logradouro");
        String complemento = cv.getAsString("complemento");
        String bairro = cv.getAsString("bairro");
        String uf = cv.getAsString("uf");
        String localidade = cv.getAsString("localidade");
        String id = cv.getAsString("id");

        holder.txt_cep.setText(cep);
        holder.txt_logradouro.setText(logradouro);
        holder.txt_complemento.setText(complemento);
        holder.txt_bairro.setText(bairro);
        holder.txt_uf.setText(uf);
        holder.txt_localidade.setText(localidade);
        holder.txt_id.setText(id);
        holder.txt_id.setAlpha(0);

    }

    @Override
    public int getItemCount() {
        return endereco_lista.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView txt_cep, txt_logradouro, txt_complemento, txt_bairro, txt_localidade, txt_uf, txt_id;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txt_cep = itemView.findViewById(R.id.cep);
            txt_logradouro = itemView.findViewById(R.id.logradouro);
            txt_complemento = itemView.findViewById(R.id.complemento);
            txt_bairro = itemView.findViewById(R.id.bairro);
            txt_uf = itemView.findViewById(R.id.uf);
            txt_id = itemView.findViewById(R.id.txt_id);
            txt_localidade = itemView.findViewById(R.id.localidade);

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext(), R.style.fundo_dialogo);
                    builder.setTitle("Confirmação de exclusão");
                    builder.setMessage("Deseja excluir este endereço?");
                    builder.setCancelable(false);
                    builder.setNegativeButton("NÃO", null);
                    builder.setPositiveButton("Excluir", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            BDCep bd = new BDCep(itemView.getContext());

                            int aux_lista = Integer.parseInt(txt_id.getText().toString());
                            bd.deletarRegistro(aux_lista);

                            Toast.makeText(itemView.getContext(), "Localização removida", Toast.LENGTH_SHORT).show();

                            endereco_lista.remove(getAdapterPosition());
                            notifyItemRemoved(getAdapterPosition());

                        }
                    });
                    builder.show();
                    return true;
                }

            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(itemView.getContext(), MapsActivity2.class);
                    String endereco = txt_logradouro.getText().toString() + "," + txt_bairro.getText().toString()
                            + "," + txt_localidade.getText().toString() + "," + txt_uf.getText().toString();

                    intent.putExtra("endereco", endereco);
                    intent.putExtra("tipo", "2");
                    Toast.makeText(itemView.getContext(), "Carregando localização...", Toast.LENGTH_SHORT).show();

                    itemView.getContext().startActivity(intent);

                }
            });
        }
    }
}