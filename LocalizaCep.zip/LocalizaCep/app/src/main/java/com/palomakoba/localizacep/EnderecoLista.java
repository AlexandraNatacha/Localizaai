package com.palomakoba.localizacep;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class EnderecoLista extends AppCompatActivity {

    private RecyclerView recyclerview;
    private Button btn_voltar;
    BDCep bd;
    private List<ContentValues>endereco_lista = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_endereco_lista);

        bd = new BDCep(getApplicationContext());
        recyclerview = findViewById(R.id.recyclerView);
        btn_voltar = findViewById(R.id.btn_voltar);
        endereco_lista = bd.pesquiarPorTodos();

        Adapter adapter = new Adapter(endereco_lista);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.setHasFixedSize(true);
        recyclerview.setAdapter(adapter);

        btn_voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


    }
}