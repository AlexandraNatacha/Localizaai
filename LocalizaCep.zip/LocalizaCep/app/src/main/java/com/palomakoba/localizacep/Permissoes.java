package com.palomakoba.localizacep;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class Permissoes {
    public static boolean validatePermission(String[] permissions, Activity activity, int requestCode){

        if (Build.VERSION.SDK_INT >= 23){
            List<String> list_permissions = new ArrayList<String>();

            //Percorre as permissões passadas, checa se já tem a permissao liberada
            for (String permission : permissions) {
                Boolean success = ContextCompat.checkSelfPermission(activity, permission) == PackageManager.PERMISSION_GRANTED;
                if(!success)
                    list_permissions.add(permission);
            }

            //Se a lista estiver vazia, não precisa solicitar permissão.
            if (list_permissions.isEmpty())
                return true;

            String[] new_permissions = new String[list_permissions.size() ];
            list_permissions.toArray(new_permissions);

            //solicita permissão
            ActivityCompat.requestPermissions(activity, new_permissions,requestCode);
        }
        return true;
    }
}
