package com.palomakoba.localizacep;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.BatteryManager;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private Button bnt_cep;
    private Button bnt_lista;
    private EditText edt_cep;
    private TextView txt_cep;

    private Retrofit retrofit;

    private BDCep bd;

    private SensorManager sensorManager;
    private Sensor sensor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bnt_cep = findViewById(R.id.btn_cep);
        bnt_lista = findViewById(R.id.btn_lista);
        edt_cep = findViewById(R.id.edt_cep);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);


        localizaCEP();

        bnt_cep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edt_cep.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Preencha um CEP", Toast.LENGTH_SHORT).show();
                } else {
                    buscaCep();
                }
            }

            ;//*/


        });

        bnt_lista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, EnderecoLista.class);

                intent.putExtra("tipo", 0);
                startActivity(intent);
            }
        });


    } // build.setCancelable(false);

    private void buscaCep() {
        String cep1 = String.format(edt_cep.getText().toString());

        bd = new BDCep(getApplicationContext());

        if (edt_cep.length() != 8)
            Toast.makeText(this, "O CEP deve ter 8 dígitos", Toast.LENGTH_SHORT).show();
        else {

            Toast.makeText(MainActivity.this, "Buscando...", Toast.LENGTH_SHORT).show();

            localizaCEP();

            CEPService cepService = retrofit.create(CEPService.class);
            Call<CEP> call = cepService.recuperarCep(cep1);
            call.enqueue(new Callback<CEP>() {
                @Override
                public void onResponse(Call<CEP> call, Response<CEP> response) {

                    CEP cep = response.body();

                    if (cep.getCep() != null) {
//                        MyTask task = new MyTask();
//                        task.resp = findViewById(R.id.txt_cep);
//
//                        task.execute("https://viacep.com.br/ws/" + edt_cep.getText().toString() + "/json/");

                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setMessage("O cep: " + cep1 + ", está situado em: \n\n" + cep.getLogradouro() +
                                ", " + cep.getComplemento() + "\n" + cep.getBairro() + " - " + cep.getLocalidade() + "/" + cep.getUf());
                        builder.setTitle("LocalizaCEP");
                        builder.setCancelable(false);
                        builder.setNeutralButton("OK", null);
                        builder.setPositiveButton("Salvar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(MainActivity.this, "Localização salva", Toast.LENGTH_SHORT).show();
                                ContentValues cv = new ContentValues();

                                cv.put("cep", cep.getCep());
                                cv.put("logradouro", cep.getLogradouro());
                                cv.put("complemento", cep.getComplemento());
                                cv.put("bairro", cep.getBairro());
                                cv.put("localidade", cep.getLocalidade());
                                cv.put("uf", cep.getUf());

                                long ress = bd.inserir(cv);
                                if (ress > 0) {
                                    Toast.makeText(MainActivity.this, "Salvo com sucesso", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(MainActivity.this, "Falha ao salvar", Toast.LENGTH_SHORT).show();
                                }

                            }
                        });
                        builder.show();
                    } else {
                        Toast.makeText(MainActivity.this, "CEP inexistente", Toast.LENGTH_SHORT).show();


                    }
                }

                @Override
                public void onFailure(Call<CEP> call, Throwable t) {
                    Toast.makeText(MainActivity.this, "Erro ao encontrar CEP", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(MainActivity.this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
        this.registerReceiver(nivel_bateria, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(MainActivity.this);
        this.unregisterReceiver(nivel_bateria);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.values[0] > 20) {
            Toast.makeText(this, "Saindo do aplicativo", Toast.LENGTH_SHORT).show();
            finish();
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    public BroadcastReceiver nivel_bateria = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            int nivel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
            if (nivel < 50) {
                Toast.makeText(context, "O nível da bateria está abaixo de 50%", Toast.LENGTH_SHORT).show();

            }
        }
    };

    public void localizaCEP() {
        String urlapi = "https://viacep.com.br/ws/";
        retrofit = new Retrofit.Builder()
                .baseUrl(urlapi).addConverterFactory(GsonConverterFactory.create()).build();
    }
}
